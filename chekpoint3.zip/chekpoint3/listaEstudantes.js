listaEstudantes = [
  { nome: "rodrigo rodrigues", qtdFaltas: 4, notas: [10, 5, 10] },
  { nome: "marcus rodrigues", qtdFaltas: 1, notas: [10, 8, 9] },
  { nome: "bruno neves", qtdFaltas: 2, notas: [8.7, 8.8, 8.8] },
  { nome: "mateus praxedes", qtdFaltas: 2, notas: [8.7, 8.8, 8.8] },
  { nome: "moises bollela", qtdFaltas: 2, notas: [8.7, 8.8, 8.8] },
  { nome: "wellington siqueira", qtdFaltas: 4, notas: [8.7, 8.8, 8.8] }
];


module.exports = JSON.stringify(listaEstudantes);